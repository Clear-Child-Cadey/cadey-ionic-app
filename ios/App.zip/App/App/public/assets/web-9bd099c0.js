import{W as n}from"./index-7a45ecf2.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
